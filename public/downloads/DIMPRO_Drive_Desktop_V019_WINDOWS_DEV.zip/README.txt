DIMPRO Drive Desktop V0.1.9 - Windows Open Handler
DEV PILOT - PROD DENY

Telepites:
1. Csomagold ki a ZIP fajlt egy helyi mappaba.
2. Dupla kattintas: DIMPRO_Drive_Desktop_Install.cmd
3. A Windows PowerShell telepiti a felhasznaloi dimpro-drive:// protokollkezelot.
4. Az elso Drive Windows-megnyitaskor valaszd ki a helyi DIMPRO munkafajlok mappajat.
5. Ezutan a DIMPRO Drive webes feluleten a "Megnyitas Windowsban" gomb a Windows alapertelmezett alkalmazasaval nyitja meg a fajlt.

Fontos:
- Nincs szukseg rendszergazdai telepitesre; HKCU protokollregisztracio keszul.
- A V0.1.9 egyszer hasznalatos, rovid elettu webes open-ticketet hasznal.
- A BENJADMIN Developer Grid Windows Bridge token nem szukseges a fajlmegnyitashoz.
- Ez NEM teljes Drive-szinkron. Csak a tenylegesen megnyitott munkafajlok kerulnek a helyi mappaba.
- A helyileg modositott fajlt a kliens nem irja felul automatikusan.
- DEV PILOT. PROD hasznalat nincs engedelyezve.

Eltavolitas:
DIMPRO_Drive_Desktop_Uninstall.cmd
A helyi munkafajlok eltavolitaskor nem torlodnek.
